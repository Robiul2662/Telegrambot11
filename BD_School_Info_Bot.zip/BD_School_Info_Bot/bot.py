import os
import logging
import re
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters

from school_data import search_schools_by_eiin, search_schools_by_text

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=os.getenv("LOG_LEVEL", "INFO"),
)
logger = logging.getLogger(__name__)

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()

HELP_TEXT = (
    "BD School Info Bot ব্যবহারবিধি\n\n"
    "/start — বট চালু\n"
    "/help — ব্যবহারবিধি\n"
    "/search — স্কুলের নাম/জেলা/উপজেলা দিয়ে খোঁজা\n"
    "/eiin 123456 — EIIN দিয়ে খোঁজা\n"
    "/district — জেলা/উপজেলা লিখে খোঁজা\n"
    "/about — বটের পরিচিতি\n\n"
    "নোট: এই বেসিক সংস্করণে শুধু আপনি school_data.py-তে যোগ করা যাচাইকৃত তথ্য দেখানো হবে।"
)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "আসসালামু আলাইকুম! এটি BD School Info Bot।\n\n"
        "স্কুলের EIIN বা নাম লিখে খুঁজুন।\n"
        "সহায়তার জন্য /help চাপুন।"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(HELP_TEXT)

async def about(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "BD School Info Bot স্কুলের প্রকাশ্য ও যাচাইকৃত তথ্য খুঁজতে তৈরি করা হয়েছে।\n"
        "তথ্যসূত্র না থাকলে কোনো তথ্যকে নিশ্চিত বলে দেখানো হবে না।"
    )

async def search_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = " ".join(context.args).strip()
    if not query:
        await update.message.reply_text("স্কুলের নাম, EIIN, জেলা বা উপজেলা লিখুন। উদাহরণ: /search Dhaka")
        return
    await send_search_results(update, query)

async def eiin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = " ".join(context.args).strip()
    if not query:
        await update.message.reply_text("ব্যবহার: /eiin 123456")
        return
    if not re.fullmatch(r"\d{4,8}", query):
        await update.message.reply_text("EIIN নম্বরটি ৪–৮ সংখ্যার হতে হবে।")
        return
    results = search_schools_by_eiin(query)
    await format_results(update, results, f"EIIN {query}")

async def district_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "জেলা বা উপজেলা লিখে পাঠান। উদাহরণ: কুড়িগ্রাম অথবা নাগেশ্বরী।"
    )

async def text_search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = (update.message.text or "").strip()
    if not query:
        return
    if re.fullmatch(r"\d{4,8}", query):
        results = search_schools_by_eiin(query)
        await format_results(update, results, f"EIIN {query}")
    else:
        await send_search_results(update, query)

async def send_search_results(update: Update, query: str):
    results = search_schools_by_text(query)
    await format_results(update, results, query)

async def format_results(update: Update, results, query: str):
    if not results:
        await update.message.reply_text(
            f"“{query}” এর জন্য এই বটের বর্তমান যাচাইকৃত তালিকায় কোনো তথ্য পাওয়া যায়নি।\n\n"
            "এটি মানে এই নয় যে স্কুলটি নেই। সরকারি উৎস থেকে যাচাইকৃত তথ্য যোগ করতে হবে।"
        )
        return
    lines = [f"🔎 ফলাফল: {query}", ""]
    for item in results[:10]:
        lines.append(f"🏫 {item.get('name', 'নাম পাওয়া যায়নি')}")
        lines.append(f"EIIN: {item.get('eiin', 'প্রকাশিত নয়')}")
        lines.append(f"ধরন: {item.get('school_type', 'তথ্য নেই')}")
        lines.append(f"এলাকা: {item.get('upazila', 'তথ্য নেই')}, {item.get('district', 'তথ্য নেই')}")
        lines.append(f"ওয়েবসাইট/উৎস: {item.get('source_url', 'উৎস যোগ করা হয়নি')}")
        staff = item.get("staff", [])
        if staff:
            lines.append("প্রকাশ্য পেশাগত তথ্য:")
            for person in staff[:10]:
                lines.append(f"• {person.get('name', 'নাম নেই')} — {person.get('designation', 'পদবি নেই')}")
                if person.get("subject"):
                    lines.append(f"  বিষয়: {person['subject']}")
                if person.get("source_url"):
                    lines.append(f"  উৎস: {person['source_url']}")
        else:
            lines.append("শিক্ষক/কর্মচারীর যাচাইকৃত প্রকাশ্য তালিকা এই ডেটায় নেই।")
        lines.append("")
    await update.message.reply_text("\n".join(lines), disable_web_page_preview=True)

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logger.exception("Unhandled bot error", exc_info=context.error)

def main():
    if not BOT_TOKEN:
        raise RuntimeError(
            "BOT_TOKEN পাওয়া যায়নি। Render-এর Environment Variables-এ BOT_TOKEN সেট করুন।"
        )
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("search", search_command))
    app.add_handler(CommandHandler("eiin", eiin_command))
    app.add_handler(CommandHandler("district", district_command))
    app.add_handler(CommandHandler("about", about))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_search))
    app.add_error_handler(error_handler)
    logger.info("BD School Info Bot starting")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
