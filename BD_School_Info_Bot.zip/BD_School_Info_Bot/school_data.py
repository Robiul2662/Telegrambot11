"""
এখানে কেবল সরকারি/অনুমোদিত উৎস থেকে যাচাই করা স্কুলের তথ্য যোগ করুন।
নমুনা হিসেবে ইচ্ছাকৃতভাবে কোনো বাস্তব স্কুল বা ব্যক্তির তথ্য রাখা হয়নি।
"""
SCHOOLS = [
    # উদাহরণ কাঠামো:
    # {
    #   "name": "যাচাইকৃত স্কুলের নাম",
    #   "eiin": "123456",
    #   "school_type": "সরকারি মাধ্যমিক বিদ্যালয়",
    #   "district": "জেলার নাম",
    #   "upazila": "উপজেলার নাম",
    #   "source_url": "https://সরকারি-ওয়েবসাইটের-সঠিক-লিংক",
    #   "staff": [
    #       {
    #           "name": "প্রকাশ্যে তালিকাভুক্ত শিক্ষকের নাম",
    #           "designation": "সহকারী শিক্ষক",
    #           "subject": "বাংলা",
    #           "source_url": "https://তথ্যসূত্রের-সঠিক-লিংক"
    #       }
    #   ]
    # }
]

def search_schools_by_eiin(eiin: str):
    return [s for s in SCHOOLS if str(s.get("eiin", "")) == str(eiin)]

def search_schools_by_text(query: str):
    q = query.casefold()
    fields = ("name", "eiin", "district", "upazila", "school_type")
    matches = []
    for school in SCHOOLS:
        if any(q in str(school.get(field, "")).casefold() for field in fields):
            matches.append(school)
    return matches
