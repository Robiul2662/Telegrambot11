# BD School Info Bot

বাংলাদেশের স্কুলের প্রকাশ্য তথ্য খোঁজার জন্য একটি বেসিক Telegram bot।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এই প্রজেক্টে কোনো সরকারি ডেটাবেসে স্বয়ংক্রিয় প্রবেশাধিকার বা সম্পূর্ণ শিক্ষক তালিকা নেই। `school_data.py`-তে সরকারি/অনুমোদিত উৎস থেকে যাচাই করা তথ্য যোগ না করা পর্যন্ত সার্চের ফলাফল ফাঁকা থাকবে। এটি ইচ্ছাকৃত; বট বানানো তথ্য দেখায় না।

## লোকাল চালানো
1. Python 3.10 বা নতুন সংস্করণ ইনস্টল করুন।
2. টার্মিনালে প্রজেক্ট ফোল্ডারে যান।
3. চালান: `pip install -r requirements.txt`
4. পরিবেশ ভেরিয়েবল `BOT_TOKEN`-এ BotFather থেকে পাওয়া টোকেন সেট করুন।
5. চালান: `python bot.py`

Android-এ Termux ব্যবহার করলে Python ইনস্টল করে একই কমান্ডগুলো চালানো যায়, তবে ২৪ ঘণ্টা অনলাইনে রাখার জন্য Render Worker সুবিধাজনক।

## Render-এ চালানো
1. এই ZIP ফাইলটি extract করে GitHub repository-তে আপলোড করুন।
2. Render-এ New + > Blueprint অথবা Background Worker তৈরি করুন।
3. repository সংযুক্ত করুন। `render.yaml` ব্যবহার করলে worker configuration তৈরি হবে।
4. Render Dashboard > Service > Environment-এ `BOT_TOKEN` নামে environment variable যোগ করুন।
5. Value ঘরে BotFather-এর আসল bot token দিন; অন্য কারও সঙ্গে শেয়ার করবেন না।
6. Deploy করুন এবং Logs-এ `BD School Info Bot starting` দেখুন।

## বট কমান্ড
- `/start`
- `/help`
- `/search স্কুলের নাম বা এলাকা`
- `/eiin 123456`
- `/district`
- `/about`

## যাচাইকৃত স্কুলের তথ্য যোগ করা
`school_data.py`-এর `SCHOOLS` তালিকায় উদাহরণ কাঠামো অনুসরণ করে তথ্য যোগ করুন। `source_url`-এ প্রকৃত সরকারি/অনুমোদিত উৎসের লিংক দিন। শিক্ষক/কর্মচারীর কেবল প্রকাশ্যে প্রকাশিত পেশাগত তথ্য যোগ করুন। ব্যক্তিগত ফোন, বাসার ঠিকানা, NID বা গোপন তথ্য যোগ করবেন না।

## নিরাপত্তা
- Bot token কখনো GitHub-এ আপলোড করবেন না।
- `.env` ফাইল Git-এ কমিট করবেন না।
- টোকেন ফাঁস হলে BotFather দিয়ে token revoke/regenerate করুন।
